 public class MainFile {
    public static void main(String[] args)throws Exception {
	   	try{
	   		new FrontImage();
	   	}
	   	catch(Exception ex){
	     	System.out.println (ex);
		}	
	}
}
